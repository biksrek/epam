export const productCategories = ["accessories", "apparel", "bags", "drinkware", "office", "brand"];
