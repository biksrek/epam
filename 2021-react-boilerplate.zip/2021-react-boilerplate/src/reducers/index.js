import { combineReducers } from 'redux'

import counterReducer from './counter-reducer';
import productReducer from './product-reducer';
import cartReducer from './cart-reducer';
import PropTypes from "prop-types";

const rootReducer = combineReducers({
    counter: counterReducer,
    product: productReducer,
    cart: cartReducer
})

rootReducer.propTypes = {
    counter: PropTypes.object,
    product: PropTypes.object,
    cart: PropTypes.object
};

export default rootReducer;
