const cartReducer = (state = {}, action) => {
    switch (action.type) {
        case 'ADD_TO_CART':
            const {cart = []} = state;
            const nc = [...cart, action.payload];
            
          return action.payload;
        default:
            return state
    }
}
  
export default cartReducer;
  