const productReducer = (state = {}, action) => {
  switch (action.type) {
      case 'ACTIVE_CATEGORY':
          return {...state, activeCategory: action.payload}
      default:
          return state
  }
}

export default productReducer;
