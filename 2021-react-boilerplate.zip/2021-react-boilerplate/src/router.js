import {BrowserRouter as Router, Link, Route, Switch} from "react-router-dom";
import Counter from "./components/counter";

import App from "./App";
import React from "react";
import Employee from "./components/employee/employee";
import ProductCategory from './components/product/category';
import ProductList from './components/product/listing';
import CartDetails from './components/cart';

export const RouterConfig = ()=> {
    return <Router>
        <div>
            <nav>
                <ul>
                    <li>
                        <Link to="/">Home</Link>
                    </li>
                    {/* <li>
                        <Link to="/counter">Counter Example</Link>
                    </li> */}
                    {/* <li>
                        <Link to="/employees">Employee</Link>
                    </li> */}
                    {/* <li>
                        <Link to="/products">products</Link>
                    </li> */}
                    <li>
                        <Link to="/cart">cart</Link>
                    </li>
                </ul>
            </nav>

            <Switch>
                {/* <Route path="/counter">
                    <Counter/>
                </Route>
                <Route path="/employees">
                    <Employee/>
                </Route>
                <Route path="/productCore">
                    <Employee/>
                </Route>
                <Route path="/core-app">
                    <App/>
                </Route> */}
                
                <Route path="/products/:category">
                    <ProductList/>
                </Route>
                <Route path="/cart">
                    <CartDetails/>
                </Route>
                <Route path="/">
                    <ProductCategory/>
                </Route>
            </Switch>
        </div>
    </Router>
}
