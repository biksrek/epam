import React, { useEffect } from "react";
// import {products} from './data/products';
import { useSelector, useDispatch } from 'react-redux';
import { useHistory, useParams } from "react-router-dom";
import {getApplicableCategory} from '../../utils/product';

function ProductList(params) {
    const dispatch = useDispatch();
    const history = useHistory();
    const { category } = useParams();
    const listings = useSelector((state) => state.product.listings)
    const categories = useSelector((state) => state.product.categories)
    const cart = useSelector((state) => state.cart)
    console.log("listings, categories", listings, categories)
    
    // console.log("i am called", activeCategory)
    return (
        <div>
            {
                getApplicableCategory(listings, category).map((elem, index) => {
                    return (
                        <div key={index}>
                            <p>
                                {
                                    elem.name
                                }
                            </p>
                            <p>
                                {
                                    elem.description
                                }
                            </p>
                            <p>
                                {
                                    elem.category
                                }
                            </p>
                            <button onClick={() => {
                                dispatch({ type: 'ADD_TO_CART', payload: [...cart, elem] });
                                history.push('/cart')
                            }} >Add to cart</button>
                        </div>
                    )
                })
            }
        </div>
    )
}

export default ProductList;
