// import { productCategories } from './data/product-categories';
import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useHistory } from "react-router-dom";
import {getApplicableCategory} from '../../utils/product';

function ProductCategory() {
    const dispatch = useDispatch();
    const history = useHistory();
    const listings = useSelector((state) => state.product.listings)
    const categories = useSelector((state) => state.product.categories)
    console.log("listings, categories", listings, categories)
    // const products = useSelector((state) => state.counter);
    // () => dispatch({ type: 'INCREMENT' })
    // const 
    return (
        <div>
            {
                categories.map((category, index) => {
                    return (
                        <div>
                        <table>
                        <tr>
                            <td>
                                <button key={index} onClick={() => {
                                    history.push(`/products/${category}`);
                                }}>{category}</button>
                            </td>
                            <td>
                                ------ available-count --------
                            </td>
                            <td>
                                {getApplicableCategory(listings, category).length}
                            </td>
                        </tr>
                        </table>
                        
                        </div>
                    )
                })
            }
        </div>
    )
}

export default ProductCategory;