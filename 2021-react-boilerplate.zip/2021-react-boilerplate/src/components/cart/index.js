import React from "react";
import { useSelector } from 'react-redux';
import {getApplicableCategory, uniqBy, getApplicableCategoryById} from '../../utils/product';

function CartDetails(params) {
    const cart = useSelector((state) => {
        console.log("state", state.cart)
        return state.cart;
    });
    console.log(cart)
    return (
        <div>
            {
                uniqBy(cart, 'id').map((c, i) => {
                    return (
                        <div>
                            <p>
                                {c.price}
                            </p>
                            <p>
                                {c.name}
                            </p>
                            <p>
                                {getApplicableCategoryById(cart, c.id).length}
                            </p>
                        </div>
                    )
                })
            }
        </div>
    )
}

export default CartDetails;
